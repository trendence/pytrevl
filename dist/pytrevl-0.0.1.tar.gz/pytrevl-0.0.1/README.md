
![logo](pyTREVL_logo.png)
**What is pyTREVL?**

pyTREVL is a Python package, used as an interface to handle and modify TREVL backed visualizations.